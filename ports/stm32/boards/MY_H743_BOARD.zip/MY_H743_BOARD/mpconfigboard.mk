# Auto-generated mpconfigboard.mk for MY_H743_BOARD
BOARD := MY_H743_BOARD

MICROPY_BOARD_C_SRCS += $(SRC_DIR)/boards/MY_H743_BOARD/sdram_data.c
MICROPY_BOARD_EXTRA_OBJ :=

# enable SDRAM in build
CFLAGS += -DMICROPY_HW_ENABLE_SDRAM
